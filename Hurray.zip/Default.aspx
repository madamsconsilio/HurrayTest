﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Hurray2.Default" Async="true" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>HURRAY! Privilege Analysis</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
            margin: 20px; 
            background-color: #f5f5f7;
            color: #1d1d1f;
        }
        .container {
            max-width: 820px;
            margin: 0 auto;
            background: #ffffff;
            padding: 24px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }
        .card-header {
            font-size: 15px;
            font-weight: 600;
            color: #1d1d1f;
            margin-top: 0;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #333; }
        .form-control { 
            width: 100%; 
            padding: 8px 12px; 
            font-size: 14px; 
            border: 1px solid #d2d2d7; 
            border-radius: 6px; 
            box-sizing: border-box; 
            background: #fafafa;
        }
        .btn { 
            padding: 8px 16px; 
            border: none; 
            font-size: 14px; 
            font-weight: 500;
            border-radius: 6px; 
            cursor: pointer; 
            transition: background 0.15s ease;
        }
        .btn-primary { background-color: #0071e3; color: white; }
        .btn-primary:hover { background-color: #0077ed; }
        .btn-settings { background-color: #34c759; color: white; }
        .btn-settings:hover { background-color: #2eb04f; }
        .settings-card {
            background-color: #ffffff;
            border: 1px solid #e5e5ea;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
            background: #fbfbfd;
        }
        .status-pill {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
            margin-top: 8px;
        }
        .status-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
        .status-error { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
        .status-info { background: #e3f2fd; color: #1565c0; border: 1px solid #bbdefb; }
        .info-note { font-size: 12px; color: #6e6e73; margin-top: 4px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2 style="margin-top: 0;">HURRAY! Privilege Analysis</h2>

            <!-- RELATIVITY USER / WORKSPACE INFO -->
            <div style="margin-bottom: 20px;">
                <asp:Label ID="DisplayLabel" runat="server" BorderColor="#d2d2d7" BorderWidth="1px" BorderStyle="Solid" 
                    BackColor="#fbfbfd" Style="padding: 10px; display: block; border-radius: 6px; font-size: 13px;" Text=""></asp:Label>
            </div> 

            <!-- FILTERS & DROPDOWNS -->
            <div class="form-group">
                <label for="ddlDynamicOptions">Select Folder:</label>
                <asp:DropDownList ID="ddlDynamicOptions" runat="server" CssClass="form-control"></asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="ddlFields">Select Target PRIV Field:</label>
                <asp:DropDownList ID="ddlFields" runat="server" CssClass="form-control"></asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="ddlHurrayProjects">Select Hurray! Configuration / Project:</label>
                <asp:DropDownList ID="ddlHurrayProjects" runat="server" CssClass="form-control"></asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="txtUserPrompt">Instructions / Prompt for Claude:</label>
                <asp:TextBox ID="txtUserPrompt" runat="server" TextMode="MultiLine" Rows="3" CssClass="form-control" 
                    Text="Analyze the document text and determine if it contains privileged legal communications (Attorney-Client or Work-Product). State your reasoning and confidence level."></asp:TextBox>
            </div>
            <!-- Floodgate Token Section -->
            <div class="section">
                <div class="section-title">Floodgate Authentication</div>
                <div class="form-group">
                    <label for="<%= txtFloodgateToken.ClientID %>">Floodgate ID Token:</label>
                    <asp:TextBox ID="txtFloodgateToken" runat="server" CssClass="form-control" TextMode="Password" 
                                 placeholder="Paste oauth-id-token from appleconnect here..." AutoCompleteType="Disabled" />
                    <div class="hint-text">
                        Obtain token via terminal: 
                        <code>appleconnect getToken -C hvys3fcwcteqrvw3qzkvtk86viuoqv --token-type=oauth -G pkce -o "openid,dsid,accountname,profile,groups"</code>
                    </div>
                </div>
                <asp:Button ID="btnSaveToken" runat="server" Text="Save Token" CssClass="btn" OnClick="btnSaveToken_Click" />
                <asp:Label ID="lblTokenStatus" runat="server" CssClass="status-badge" />
            </div>
            <br /><br />
            <div class="section">
                <div class="section-title">Floodgate Test</div>
                <asp:Button ID="btnTestFloodgate" runat="server" Text="Test Floodgate Connection" CssClass="btn" OnClick="btnTestFloodgate_Click" />
                <div style="margin-top: 10px;">
                    <asp:Label ID="lblFloodgateResponse" runat="server" />
                </div>
            </div>
            <br /><br />
            <div>
                <asp:Button ID="btnGetControlNumbers" runat="server" Text="Analyze Top 10 Documents" CssClass="btn btn-primary" OnClick="btnGetControlNumbers_Click" />
                <br /><br />
                <asp:Label ID="lblControlNumbers" runat="server" />
            </div>
        </div>
    </form>
</body>
</html>