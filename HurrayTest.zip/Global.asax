﻿<%@ Application Codebehind="Global.asax.cs" Inherits="HurrayTest.Global" Language="C#" %>
