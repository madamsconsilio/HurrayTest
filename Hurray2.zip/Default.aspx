﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Hurray2.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>Default Page
        </div>
        <asp:Label ID="DisplayLabel" runat="server" BorderColor="Blue" BorderStyle="Double" Text="Label"></asp:Label>
    </form>
</body>
</html>
