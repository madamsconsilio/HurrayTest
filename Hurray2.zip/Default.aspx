﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Hurray2.Default" Async="true" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>Hurray! Relativity Options</div>
        <br /><br />
        <div>
            <asp:Label ID="DisplayLabel" runat="server" BorderColor="Blue" BorderStyle="Double" Text="Label"></asp:Label>
        </div> 
        <br /><br />
        <div>
            <label for="ddlDynamicOptions">Select Folder:</label>
            <asp:DropDownList ID="ddlDynamicOptions" runat="server" AutoPostBack="false"></asp:DropDownList>
        </div>
        <br /><br />
        <div>
            <label for="ddlFields">Select PRIV Field:</label>
            <asp:DropDownList ID="ddlFields" runat="server" AutoPostBack="false"></asp:DropDownList>
        </div>
        <div>
            <asp:Button ID="btnGetControlNumbers" runat="server" Text="Get Top 10 Control Numbers" OnClick="btnGetControlNumbers_Click" />
            <br /><br />
            <asp:Label ID="lblControlNumbers" runat="server" />
        </div>
    </form>
</body>
</html>
