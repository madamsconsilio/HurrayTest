﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Hurray2.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>Default Page</div>
        <br /><br />
        <div>
            <asp:Label ID="DisplayLabel" runat="server" BorderColor="Blue" BorderStyle="Double" Text="Label"></asp:Label>
        </div> 
        <br /><br />
        <div>
            <label for="ddlDynamicOptions">Select Folder:</label>
            <asp:DropDownList ID="ddlDynamicOptions" runat="server" AutoPostBack="false"></asp:DropDownList>
        </div>
    </form>
</body>
</html>
