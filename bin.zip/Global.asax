﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Hurray2.Global" Language="C#" %>
